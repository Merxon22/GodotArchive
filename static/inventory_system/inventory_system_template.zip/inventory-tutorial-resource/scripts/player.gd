class_name Player extends Node2D

static var instance: Player

func _ready() -> void:
	if instance == null:
		instance = self
	else:
		queue_free()
